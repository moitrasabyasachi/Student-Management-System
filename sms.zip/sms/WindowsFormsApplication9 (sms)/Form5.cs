﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form5 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com,com1,com2;
        OleDbDataReader dr,dr1;
        int i,i1,i2,i3,r,r1;
        string s,s1,s2,s3;

        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            try
            {
                com = new OleDbCommand("select student.enroll_no,student.sname,student.cname,student.c_str_dt,student.c_end_dt,course.cf from student left outer join course on(student.cname=course.cname) where student.enroll_no=@p1", con);
                com1 = new OleDbCommand("select total_paid_amt,due_amt from " + textBox1.Text, con);
                con.Open();
                com.Parameters.AddWithValue("@p1", textBox1.Text);
                dr = com.ExecuteReader();            
                                
                while (dr.Read())
                {
                    textBox15.Text = dr[0].ToString();
                    textBox2.Text = dr[1].ToString();
                    textBox3.Text = dr[2].ToString();
                    textBox13.Text = dr[3].ToString();
                    textBox14.Text = dr[4].ToString();
                    textBox4.Text = dr[5].ToString();                        
                }

                if (textBox16.Text == "")
                    textBox17.Text = textBox4.Text;
                else if (textBox16.Text != "")
                {
                    int cf = Int32.Parse(textBox4.Text);
                    float st = float.Parse(textBox16.Text);

                    float tcf = (cf * st / 100) + cf;

                    textBox17.Text = tcf.ToString();
                }

                if (textBox15.Text == "")
                {
                    MessageBox.Show("student not found");
                    textBox1.Clear();
                }
                else if (textBox15.Text != "")
                {
                    if (textBox4.Text == "")
                        textBox4.Enabled = true;
                    else if (textBox4.Text != "")
                        textBox4.Enabled = false;

                    dr1 = com1.ExecuteReader();

                    while (dr1.Read())
                    {
                        textBox7.Text = dr1[0].ToString();
                        textBox8.Text = dr1[1].ToString();
                    }

                    if (textBox7.Text == "" & textBox8.Text=="")
                    {
                        textBox7.Text = "0";
                        textBox8.Text = textBox4.Text;
                    }

                    if (textBox8.Text == "0")
                    {
                        MessageBox.Show("payment cleared");

                        textBox1.Clear();
                        textBox15.Clear();
                        textBox2.Clear();
                        /*if(textBox2.Enabled == true)
                            textBox2.Enabled = false;*/

                        textBox3.Clear();
                        /*if (textBox3.Enabled == true)
                            textBox3.Enabled = false;*/

                        textBox13.Clear();
                        /*if (textBox13.Enabled == true)
                            textBox13.Enabled = false;*/

                        textBox14.Clear();
                        /*if (textBox14.Enabled == true)
                            textBox14.Enabled = false;*/

                        textBox4.Clear();
                        /*if (textBox4.Enabled == true)
                            textBox4.Enabled = false;*/
                        textBox17.Clear();
                        comboBox2.Text = "--SELECT--";
                        textBox5.Clear();
                        textBox6.Text = "0";
                        textBox18.Clear();
                        textBox7.Clear();
                        /*if (textBox7.Enabled == true)
                            textBox7.Enabled = false;*/

                        textBox8.Clear();
                        /*if (textBox8.Enabled == true)
                            textBox8.Enabled = false;*/

                        comboBox1.Text = "--SELECT--";

                        textBox9.Clear();
                        if (textBox9.Enabled == true)
                            textBox9.Enabled = false;

                        textBox10.Clear();
                        if (textBox10.Enabled == true)
                            textBox10.Enabled = false;

                        textBox11.Clear();
                        if (textBox11.Enabled == true)
                            textBox11.Enabled = false;

                        /*textBox12.Clear();
                        if (textBox12.Enabled == true)
                            textBox12.Enabled = false;*/

                        dateTimePicker3.ResetText();
                        //button2.Enabled = false;
                    }                    
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }	
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
            /*textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox13.Enabled = false;
            textBox14.Enabled = false;*/
            textBox4.Enabled = false;
            textBox17.Enabled = false;
            textBox18.Enabled = false;
            textBox7.Enabled = false;
            textBox8.Enabled = false;
            textBox9.Enabled = false;
            textBox10.Enabled = false;
            textBox11.Enabled = false;
            /*textBox12.Enabled = false;
            dateTimePicker3.Enabled = false;*/            

            try
            {
                com = new OleDbCommand("select * from reciept_count", con);
                con.Open();
                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    s = dr[0].ToString();
                }

                i = Int32.Parse(s);
                i1 = i + 1;
                textBox12.Text = i1.ToString();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }    
        }

        /*private void button3_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                MessageBox.Show("enter amount");
                textBox6.Focus();
            }
            else if (textBox6.Text != "")
            {
                if (textBox4.Text == "")
                {
                    MessageBox.Show("course fee missing");
                    textBox6.Clear();
                    textBox4.Focus();
                }
                else if (textBox4.Text != "")
                {
                    s = textBox4.Text;
                    i = Int32.Parse(s);

                    s1 = textBox6.Text;
                    i1 = Int32.Parse(s1);


                    if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (textBox16.Text == "")
                            textBox18.Text = textBox6.Text;
                        else if (textBox16.Text != "")
                        {
                            int f = Int32.Parse(textBox6.Text);
                            float st = float.Parse(textBox16.Text);

                            float pa = (f * st / 100) + f;

                            textBox18.Text = pa.ToString();
                        }

                        if (textBox7.Text == "0" && textBox8.Text == textBox4.Text)
                        {
                            textBox7.Text = textBox6.Text;
                            r = i - i1;
                            textBox8.Text = r.ToString();
                        }
                        else if (textBox7.Text != "" && textBox8.Text != "")
                        {
                            s2 = textBox7.Text;
                            i2 = Int32.Parse(s2);

                            s3 = textBox8.Text;
                            i3 = Int32.Parse(s3);


                            r1 = i2 + i1;
                            textBox7.Text = r1.ToString();

                            r = i3 - i1;
                            textBox8.Text = r.ToString();
                        }
                    }
                }
            }
        }*/

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Cheque" || comboBox1.Text == "DD")
            {
                textBox9.Enabled = true;
                textBox10.Enabled = true;
                textBox11.Enabled = true;
            }

            else if (comboBox1.Text == "Cash")
            {
                textBox9.Enabled = false;
                textBox10.Enabled = false;
                textBox11.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int amt = Int32.Parse(textBox6.Text), tfp = Int32.Parse(textBox7.Text), da = Int32.Parse(textBox8.Text);
                
                tfp = tfp + amt;
                da = da - amt;

                textBox7.Text = tfp.ToString();
                textBox8.Text = da.ToString();

                try
                {
                    com = new OleDbCommand("insert into " + textBox1.Text + " values(@p1,@p2,@p3,@p4,@p5,@p6,@p17,@p18,@p19,@p7,@p8,@p20,@p9,@p10,@p11,@p12,@p13,@p14,@p15,@p16)", con);
                    com1 = new OleDbCommand("insert into reciept_count values(@p15)", con);
                    com2 = new OleDbCommand("insert into collection values(@p1,@p2,@p3,@p4,@p5,@p6,@p17,@p18,@p19,@p7,@p8,@p20,@p9,@p10,@p11,@p12,@p13,@p14,@p15,@p16)", con);
                    //com3 = new OleDbCommand("select * from reciept_count", con);

                    con.Open();

                    com.Parameters.AddWithValue("@p1", textBox15.Text);
                    com.Parameters.AddWithValue("@p2", textBox2.Text);
                    com.Parameters.AddWithValue("@p3", textBox3.Text);
                    com.Parameters.AddWithValue("@p4", textBox13.Text);
                    com.Parameters.AddWithValue("@p5", textBox14.Text);
                    com.Parameters.AddWithValue("@p6", textBox4.Text);
                    com.Parameters.AddWithValue("@p17", textBox16.Text);
                    com.Parameters.AddWithValue("@p18", textBox17.Text);
                    com.Parameters.AddWithValue("@p19", comboBox2.Text);
                    com.Parameters.AddWithValue("@p7", textBox5.Text);
                    com.Parameters.AddWithValue("@p8", textBox6.Text);
                    com.Parameters.AddWithValue("@p20", textBox18.Text);
                    com.Parameters.AddWithValue("@p9", textBox7.Text);
                    com.Parameters.AddWithValue("@p10", textBox8.Text);
                    com.Parameters.AddWithValue("@p11", comboBox1.Text);
                    com.Parameters.AddWithValue("@p12", textBox9.Text);
                    com.Parameters.AddWithValue("@p13", textBox10.Text);
                    com.Parameters.AddWithValue("@p14", textBox11.Text);
                    com.Parameters.AddWithValue("@p15", textBox12.Text);
                    com.Parameters.AddWithValue("@p16", dateTimePicker3.Text);

                    com1.Parameters.AddWithValue("@p15", textBox12.Text);

                    com2.Parameters.AddWithValue("@p1", textBox15.Text);
                    com2.Parameters.AddWithValue("@p2", textBox2.Text);
                    com2.Parameters.AddWithValue("@p3", textBox3.Text);
                    com2.Parameters.AddWithValue("@p4", textBox13.Text);
                    com2.Parameters.AddWithValue("@p5", textBox14.Text);
                    com2.Parameters.AddWithValue("@p6", textBox4.Text);
                    com2.Parameters.AddWithValue("@p17", textBox16.Text);
                    com2.Parameters.AddWithValue("@p18", textBox17.Text);
                    com2.Parameters.AddWithValue("@p19", comboBox2.Text);
                    com2.Parameters.AddWithValue("@p7", textBox5.Text);
                    com2.Parameters.AddWithValue("@p8", textBox6.Text);
                    com2.Parameters.AddWithValue("@p20", textBox18.Text);
                    com2.Parameters.AddWithValue("@p9", textBox7.Text);
                    com2.Parameters.AddWithValue("@p10", textBox8.Text);
                    com2.Parameters.AddWithValue("@p11", comboBox1.Text);
                    com2.Parameters.AddWithValue("@p12", textBox9.Text);
                    com2.Parameters.AddWithValue("@p13", textBox10.Text);
                    com2.Parameters.AddWithValue("@p14", textBox11.Text);
                    com2.Parameters.AddWithValue("@p15", textBox12.Text);
                    com2.Parameters.AddWithValue("@p16", dateTimePicker3.Text);

                    if (comboBox2.Text == "--SELECT--" || textBox5.Text == "" || textBox6.Text == "" || comboBox1.Text == "--SELECT--")
                    {
                        MessageBox.Show("information inadequate,check once");
                        textBox1.Focus();
                    }
                    else
                    {
                        if ((comboBox1.Text=="Cheque" || comboBox1.Text=="DD") && (textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == ""))
                        {
                            MessageBox.Show("supply cheque/dd no., bank name & branch name");
                            textBox9.Focus();
                        }
                        else
                        {
                            i = com.ExecuteNonQuery();

                            com1.ExecuteNonQuery();

                            com2.ExecuteNonQuery();


                            MessageBox.Show(i + " payment made successfully ");

                            button2.Enabled = false;                            
                        }
                    }
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }                
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox15.Clear();
            textBox2.Clear();
            /*if(textBox2.Enabled == true)
                textBox2.Enabled = false;*/

            textBox3.Clear();
            /*if (textBox3.Enabled == true)
                textBox3.Enabled = false;*/

            textBox13.Clear();
            /*if (textBox13.Enabled == true)
                textBox13.Enabled = false;*/
            
            textBox14.Clear();
            /*if (textBox14.Enabled == true)
                textBox14.Enabled = false;*/
            
            textBox4.Clear();
            /*if (textBox4.Enabled == true)
                textBox4.Enabled = false;*/
            //textBox16.Text = "0";
            textBox17.Clear();
            comboBox2.ResetText();
            textBox5.Clear();
            textBox6.Text = "0";
            textBox18.Clear();
            textBox7.Clear();
            /*if (textBox7.Enabled == true)
                textBox7.Enabled = false;*/

            textBox8.Clear();
            /*if (textBox8.Enabled == true)
                textBox8.Enabled = false;*/

            comboBox1.ResetText();

            textBox9.Clear();
            if (textBox9.Enabled == true)
                textBox9.Enabled = false;

            textBox10.Clear();
            if (textBox10.Enabled == true)
                textBox10.Enabled = false;

            textBox11.Clear();
            if (textBox11.Enabled == true)
                textBox11.Enabled = false;

            /*textBox12.Clear();
            if (textBox12.Enabled == true)
                textBox12.Enabled = false;*/

            dateTimePicker3.ResetText();

            textBox1.Focus();
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*if (comboBox2.Text == "Monthly")
                button3.Enabled = false;
            else if (comboBox2.Text == "Installment")
                button3.Enabled = true;*/
        }

        /*private void button5_Click(object sender, EventArgs e)
        {
            if (textBox16.Text == "")
                textBox17.Text = textBox4.Text;
            else if (textBox16.Text != "")
            {
                int cf = Int32.Parse(textBox4.Text);
                float st = float.Parse(textBox16.Text);

                float tcf = (cf * st / 100) + cf;

                textBox17.Text = tcf.ToString();
            }
        }*/

        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {                
                textBox16.Text = "12.36";                
                textBox1.Focus();                
            }
            else
            {
                if (textBox16.Text == "")
                    textBox17.Text = textBox4.Text;
                else if (textBox16.Text != "")
                {
                    int cf = Int32.Parse(textBox4.Text);
                    float st = float.Parse(textBox16.Text);

                    float tcf = (cf * st / 100) + cf;

                    textBox17.Text = tcf.ToString();
                }
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                MessageBox.Show("enter amount");
                textBox18.Clear();
                textBox6.Focus();
            }
            else
            {
                if (textBox16.Text == "")
                    textBox18.Text = textBox6.Text;
                else if (textBox16.Text != "")
                {
                    int amt = Int32.Parse(textBox6.Text);
                    float st = float.Parse(textBox16.Text);

                    float pa = (amt * st / 100) + amt;

                    textBox18.Text = pa.ToString();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select * from reciept_count", con);

                con.Open();


                Form f6 = new Form6(textBox15.Text, textBox2.Text, textBox3.Text, comboBox2.Text, textBox5.Text, textBox6.Text, textBox16.Text, textBox18.Text, textBox17.Text, textBox7.Text, comboBox1.Text, textBox9.Text, textBox10.Text, textBox11.Text, textBox12.Text, dateTimePicker3.Text);
                f6.Show();                                   


                textBox1.Clear();
                textBox15.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox13.Clear();
                textBox14.Clear();
                textBox4.Clear();                
                textBox17.Clear();
                comboBox2.Text = "--SELECT--";
                textBox5.Clear();
                textBox6.Text = "0";
                textBox18.Clear();
                textBox7.Clear();
                textBox8.Clear();
                comboBox1.Text = "--SELECT--";
                
                textBox9.Clear();
                if (textBox9.Enabled == true)
                    textBox9.Enabled = false;

                textBox10.Clear();
                if (textBox10.Enabled == true)
                    textBox10.Enabled = false;

                textBox11.Clear();
                if (textBox11.Enabled == true)
                    textBox11.Enabled = false;

                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    s = dr[0].ToString();
                }

                i1 = Int32.Parse(s);
                i2 = i1 + 1;
                textBox12.Text = i2.ToString();

                dateTimePicker3.ResetText();

                button2.Enabled = true;
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        /*private void textBox6_TextChanged(object sender, EventArgs e)
        {
            
        }*/

        /*private void label21_Click(object sender, EventArgs e)
        {

        }*/

        /*private void label17_Click(object sender, EventArgs e)
        {

        }*/

        /*private void label16_Click(object sender, EventArgs e)
        {

        }*/
    }
}
