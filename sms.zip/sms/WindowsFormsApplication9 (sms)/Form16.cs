﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form16 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        //OleDbCommand com;
        OleDbDataAdapter da;

        public Form16()
        {
            InitializeComponent();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'registerDataSet1.collection' table. You can move, or remove it, as needed.
            //this.collectionTableAdapter.Fill(this.registerDataSet1.collection);
            textBox1.Focus();

            /*int c = dataGridView1.RowCount;
            MessageBox.Show(c.ToString());
            if (c != 0)
            {
                textBox1.Clear();
                dataGridView1.DataSource = null;
            }*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                da = new OleDbDataAdapter("select * from collection where enroll_no='" + textBox1.Text + "'", con);
                con.Open();
                da.Fill(registerDataSet1.collection);

                int c = dataGridView1.RowCount;
                if (c == 0)
                {
                    MessageBox.Show("student not found");
                    textBox1.Clear();
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            dataGridView1.DataSource = null;
            textBox1.Focus();
        }
    }
}
