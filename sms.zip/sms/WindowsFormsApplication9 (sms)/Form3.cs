﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form3 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com,com1;
        int i;

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    com = new OleDbCommand("delete from student where enroll_no=@p1", con);
                    com1 = new OleDbCommand("drop table " + textBox1.Text, con);
                    con.Open();
                    com.Parameters.AddWithValue("@p1", textBox1.Text);
                    i = com.ExecuteNonQuery();

                    if (i == 0)
                        MessageBox.Show("student not found");
                    else if (i > 0)
                    {
                        com1.ExecuteNonQuery();
                        MessageBox.Show(i + " record deleted successfully");
                    }

                    textBox1.Clear();

                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }
    }
}
