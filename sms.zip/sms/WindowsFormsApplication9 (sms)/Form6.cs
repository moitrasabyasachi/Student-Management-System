﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Printing;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form6 : Form
    {
        //private Button printButton = new Button();
        private PrintDocument printDocument1 = new PrintDocument();

        public Form6(string enroll_no, string sname, string cname, string pay_type, string part, string fee, string stax, string paid_amt, string tcf, string total_paid_amt, string pay_mode, string chq_dd_no, string bank, string branch, string reciept_no, string reciept_dt)
        {
            InitializeComponent();

            label16.Text = enroll_no;
            label17.Text = sname;
            label18.Text = cname;
            label36.Text = pay_type;
            label20.Text = part;
            label34.Text = fee;
            label32.Text = stax;
            label21.Text = paid_amt;
            label19.Text = tcf;
            label22.Text = total_paid_amt;
            label23.Text = pay_mode;
            label24.Text = chq_dd_no;
            label25.Text = bank;
            label26.Text = branch;
            label27.Text = reciept_no;
            label28.Text = reciept_dt;

            /*label45.Text = enroll_no;
            label46.Text = name;
            label47.Text = cid;
            label48.Text = tcf;
            label49.Text = part;
            label50.Text = paid_amt;
            label51.Text = tpa;
            label52.Text = pay_mode;
            label53.Text = chq_dd_no;
            label54.Text = bank;
            label55.Text = branch;
            label31.Text = reciept_no;
            label44.Text = reciept_dt;*/

            /*button1.Text = "Print Reciept";
            button1.Click += new EventHandler(button1_Click);*/
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            //this.Controls.Add(button1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CaptureScreen();
            printDocument1.Print();

            this.Hide();
            //Form f0 = new Form0();
            //f0.Show();
        }

        Bitmap memoryImage;

        private void CaptureScreen()
        {
            Graphics myGraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);
        }

        private void printDocument1_PrintPage(System.Object sender,
               System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }



        

        /*private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }*/
    }
}
