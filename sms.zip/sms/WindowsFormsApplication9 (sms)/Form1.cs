﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form1 : Form
    {
        OleDbConnection con=new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        SqlConnection con1 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\registration.mdf;Integrated Security=True;User Instance=True");
        OleDbCommand com;
        OleDbDataReader dr;
        SqlCommand com1;
        SqlDataReader dr1;
        string pk,st,u, p;
        Form mn = new Form0();
        Form f2 = new Form2();
        
        public Form1()
        {
            InitializeComponent();
        }

        /*private void button3_Click(object sender, EventArgs e)
        {
            Form a = new Form0();
            a.Show();
        }*/

        /*private void button1_Click(object sender, EventArgs e)
        {
            Form a = new Form0();
            a.Show();
        }*/

        /*private void button1_Click_1(object sender, EventArgs e)
        {
            
        }*/

        /*private void button1_Click(object sender, EventArgs e)
        {
            
        }*/

        /*private void button1_Click_1(object sender, EventArgs e)
        {
            
        }*/

        /*private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }*/

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            linkLabel1.Enabled = false;
            button1.Enabled = false;

            try
            {
                com1 = new SqlCommand("select * from productkey", con1);
                
                con1.Open();
                
                dr1 = com1.ExecuteReader();
                while (dr1.Read())
                {
                    pk = dr1[0].ToString();
                    st = dr1[1].ToString();
                }
                if (pk == "hijklmno" && st == "active")
                {
                    textBox1.Enabled = true;                    
                    textBox2.Enabled = true;
                    linkLabel1.Enabled = true;
                    button1.Enabled = true;
                    textBox1.Focus();
                }
                else
                {
                    Form f10 = new Form10();
                    
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    linkLabel1.Enabled = false;
                    button1.Enabled = false;
                    
                    f10.Show();                    
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con1.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select * from admin where uname=@p1", con);
                con.Open();
                com.Parameters.AddWithValue("@p1", textBox1.Text);
                
                if (textBox1.Text == "" || textBox2.Text == "")
                {
                    MessageBox.Show("incomplete entry");
                }
                else if (textBox1.Text != "" && textBox2.Text != "")
                {
                    dr = com.ExecuteReader();

                    while (dr.Read())
                    {
                        u = dr[0].ToString();
                        p = dr[1].ToString();
                    }

                    if (textBox1.Text == u && textBox2.Text == p)
                    {
                        mn.Show();
                        this.Hide();                       
                        
                    }

                    else if (textBox1.Text != u || textBox2.Text != p)
                    {
                        MessageBox.Show("invalid user name or password");

                        textBox1.Clear();
                        textBox2.Clear();
                    }
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            f2.Show();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        /*private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            
        }*/
    }
}
