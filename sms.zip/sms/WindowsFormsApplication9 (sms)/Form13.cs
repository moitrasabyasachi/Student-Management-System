﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form13 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        OleDbDataReader dr;
        int i;

        public Form13()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select * from student where enroll_no=@p1", con);
                con.Open();
                com.Parameters.AddWithValue("@p1", textBox1.Text);
                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    textBox1.Text = dr[0].ToString();
                    textBox2.Text = dr[1].ToString();
                    richTextBox1.Text = dr[2].ToString();
                    textBox3.Text = dr[3].ToString();
                    textBox9.Text = dr[4].ToString();
                    textBox4.Text = dr[5].ToString();
                    textBox5.Text = dr[6].ToString();
                    textBox6.Text = dr[7].ToString();
                    textBox7.Text = dr[8].ToString();
                    textBox8.Text = dr[9].ToString();
                    textBox10.Text = dr[10].ToString();
                    textBox11.Text = dr[11].ToString();
                }

                if (textBox2.Text == "" && richTextBox1.Text=="" && textBox3.Text == "" && textBox9.Text == "" && textBox4.Text == "" && textBox5.Text == "" && textBox6.Text == "" && textBox7.Text == "" && textBox8.Text == "" && textBox10.Text == "" && textBox11.Text == "")
                {
                    MessageBox.Show("student not found");
                    textBox1.Clear();
                }

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    com = new OleDbCommand("update student set sname='" + textBox2.Text + "',addr='" + richTextBox1.Text + "',phno='" + textBox3.Text + "',email_id='" + textBox9.Text + "',alt_phno='" + textBox4.Text + "',dob='" + textBox5.Text + "',gender='" + textBox6.Text + "',guar_name='" + textBox7.Text + "',cname='" + textBox8.Text + "',c_str_dt='" + textBox10.Text + "',c_end_dt='" + textBox11.Text + "' where enroll_no='"+textBox1.Text+"'", con);
                    con.Open();
                    i = com.ExecuteNonQuery();
                    
                    MessageBox.Show(i + " record updated successfully");
                    
                    textBox1.Clear();
                    textBox2.Clear();
                    richTextBox1.Clear();
                    textBox3.Clear();
                    textBox9.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                    textBox8.Clear();
                    textBox10.Clear();
                    textBox11.Clear();
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            richTextBox1.Clear();
            textBox3.Clear();
            textBox9.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox10.Clear();
            textBox11.Clear();

            textBox1.Focus();
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        /*private void label13_Click(object sender, EventArgs e)
        {

        }*/

        /*private void label5_Click(object sender, EventArgs e)
        {

        }*/

        /*private void label8_Click(object sender, EventArgs e)
        {

        }*/

        /*private void label11_Click(object sender, EventArgs e)
        {

        }*/

        /*private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }*/

        /*private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }*/

        /*private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }*/
    }
}
