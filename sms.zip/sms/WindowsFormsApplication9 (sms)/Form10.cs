﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form10 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\registration.mdf;Integrated Security=True;User Instance=True");
        SqlCommand com;
        SqlDataReader dr;
        string a, b;
        int i;
        
        public Form10()
        {
            InitializeComponent();
        }

        /*private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }*/

        private void Form10_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
            
            try
            {
                com = new SqlCommand("select * from productkey", con);
                
                con.Open();
                
                dr = com.ExecuteReader();
                while (dr.Read())
                {
                    a = dr[0].ToString();
                }

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());

            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            b=textBox1.Text;

            if (b == a)
            {
                try
                {
                    com = new SqlCommand("UPDATE productkey SET status = 'active' WHERE (pkey = '"+textBox1.Text+"')", con);

                    con.Open();

                    i = com.ExecuteNonQuery();

                    MessageBox.Show("application activated successfully");
                    MessageBox.Show("restart the application");
                    Application.Exit();

                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
