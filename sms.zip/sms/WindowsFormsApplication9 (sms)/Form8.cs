﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form8 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        int i;

        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    com = new OleDbCommand("insert into course values(@p1,@p2,@p3,@p4,@p5)", con);
                    con.Open();
                    com.Parameters.AddWithValue("@p1", textBox1.Text);
                    com.Parameters.AddWithValue("@p2", textBox2.Text);
                    com.Parameters.AddWithValue("@p3", textBox3.Text);
                    com.Parameters.AddWithValue("@p4", textBox4.Text);
                    com.Parameters.AddWithValue("@p5", richTextBox1.Text);
                    

                    if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || richTextBox1.Text=="")
                    {
                        MessageBox.Show("information incomplete, check once");
                    }
                    i = com.ExecuteNonQuery();
                    MessageBox.Show(i + " record added successfully");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    richTextBox1.Clear();                    
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        /*private void label4_Click(object sender, EventArgs e)
        {

        }*/
    }
}
