﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form12 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        OleDbDataReader dr;
        int i;

        public Form12()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select * from course where cid=@p1", con);
                con.Open();
                com.Parameters.AddWithValue("@p1", textBox1.Text);
                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    textBox1.Text = dr[0].ToString();
                    textBox2.Text = dr[1].ToString();
                    textBox3.Text = dr[2].ToString();
                    textBox4.Text = dr[3].ToString();
                    richTextBox1.Text = dr[4].ToString();
                    //textBox6.Text = dr[5].ToString();
                }

                if (textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "" && richTextBox1.Text == "" )
                {
                    MessageBox.Show("Record not found");
                    textBox1.Clear();
                }
                
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
            /*textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            richTextBox1.Text = "";*/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    com = new OleDbCommand("update course set cname='" + textBox2.Text + "',duration='" + textBox3.Text + "',cf='" + textBox4.Text + "',ppm='" + richTextBox1.Text + "' where cid='" + textBox1.Text + "'", con);
                    con.Open();
                    /*com.Parameters.AddWithValue("@p1", textBox1.Text);
                    com.Parameters.AddWithValue("@p2", textBox2.Text);
                    com.Parameters.AddWithValue("@p3", textBox3.Text);
                    com.Parameters.AddWithValue("@p4", textBox4.Text);
                    com.Parameters.AddWithValue("@p5", richTextBox1.Text);*/
                    i = com.ExecuteNonQuery();

                    MessageBox.Show(i + " record updated successfully");

                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    richTextBox1.Clear();
                    //textBox6.Clear();
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            richTextBox1.Clear();

            textBox1.Focus();
            //textBox6.Clear();
        }
    }
}
