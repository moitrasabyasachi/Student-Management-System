﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using Microsoft.Office.Interop.Excel;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form18 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbDataAdapter da;

        public Form18()
        {
            InitializeComponent();
        }

        private void Form18_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'registerDataSet1.course' table. You can move, or remove it, as needed.
            //this.courseTableAdapter.Fill(this.registerDataSet1.course);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                da = new OleDbDataAdapter("select * from course", con);
                con.Open();
                da.Fill(registerDataSet1.course);

                int c = dataGridView1.RowCount;
                if (c == 0)
                {
                    MessageBox.Show("no course available");
                    //textBox1.Clear();
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xlApp;

                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;

                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;



                xlApp = new Microsoft.Office.Interop.Excel.Application();

                xlWorkBook = xlApp.Workbooks.Add(misValue);

                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                int i = 0;

                int j = 0;



                for (i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xlWorkSheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }


                for (i = 0; i <= dataGridView1.RowCount - 1; i++)
                {

                    for (j = 0; j <= dataGridView1.ColumnCount - 1; j++)
                    {

                        DataGridViewCell cell = dataGridView1[j, i];

                        xlWorkSheet.Cells[i + 2, j + 1] = cell.Value;

                    }

                }

                xlWorkSheet.Columns.AutoFit();

                xlWorkBook.SaveAs("coursereport.xls", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                xlWorkBook.Close(true, misValue, misValue);

                xlApp.Quit();



                releaseObject(xlWorkSheet);

                releaseObject(xlWorkBook);

                releaseObject(xlApp);



                MessageBox.Show("course report created, you can find the file in My Documents folder with the name coursereport.xls");
            }
            else
            {
                MessageBox.Show("View Report");
            }
        }



        private void releaseObject(object obj)

        {

            try

            {

                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);

                obj = null;

            }

            catch (Exception ex)

            {

                obj = null;

                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());

            }

            finally

            {

                GC.Collect();

            }

        }        
    }
}
