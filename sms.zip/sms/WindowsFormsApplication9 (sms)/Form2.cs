﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form2 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        OleDbDataReader dr;
        string u,p;
        
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select * from admin where uname=@p1", con);
                con.Open();
                com.Parameters.AddWithValue("@p1", textBox1.Text);

                if (textBox1.Text == "")
                    MessageBox.Show("supply the username");

                else if (textBox1.Text != "")
                {
                    dr = com.ExecuteReader();

                    while (dr.Read())
                    {
                        u = dr[0].ToString();
                        p = dr[1].ToString();
                    }

                    if (textBox1.Text == u)
                        MessageBox.Show(p.ToString());

                    else if (textBox1.Text != u)
                        MessageBox.Show("username not found");

                    textBox1.Clear();
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }
    }
}
