﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form11 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        OleDbDataReader dr;

        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select * from course where cid=@p1", con);
                con.Open();
                com.Parameters.AddWithValue("@p1", textBox1.Text);
                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    MessageBox.Show("COURSE ID:\t\t" + dr[0].ToString() + "\n" + "COURSE NAME:\t\t" + dr[1].ToString() + "\n" + "COURSE DURATION:\t\t" + dr[2].ToString() + "\n" + "COURSE FEE(excl. service tax):\t" + dr[3].ToString() + "\n" + "PART PAYMENT MODE:\t" + dr[4].ToString());
                }

                textBox1.Clear();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}
