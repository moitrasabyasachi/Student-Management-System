﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form0 : Form
    {
        //Form admin = new Form1();
        Form sadd = new Form4();
        Form sdel = new Form3();
        Form cadd = new Form8();
        Form abt = new Form7();
        Form padd = new Form5();
        Form cdel = new Form9();
        //Form rdet = new Form10();
        Form cfee = new Form11();
        Form cmod = new Form12();
        Form supd = new Form13();
        Form dpr = new Form15();
        Form pd = new Form16();
        Form sr = new Form17();
        Form csr = new Form18();
        Form clr = new Form19();
   
        public Form0()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            /*studentToolStripMenuItem.Enabled = false;
            courseToolStripMenuItem.Enabled = false;*/
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            /*sadd.Close();
            sdel.Close();
            cadd.Close();
            pdel.Close();
            padd.Close();
            cdel.Close();
            rdet.Close();
            cfee.Close();
            cmod.Close();
            supd.Close();*/
            //this.Hide();
            //MessageBox.Show("logging out & exiting the application");            
            //admin.Show();
            //Application.Exit();
            //this.Close();
            //admin.Show();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sadd.TopLevel = false;
            this.panel1.Controls.Add(sadd);
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            padd.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            sadd.Show();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sdel.TopLevel = false;
            this.panel1.Controls.Add(sdel);
            sadd.Hide();
            cadd.Hide();
            //pdel.Hide();
            padd.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            sdel.Show();
        }

        private void addCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cadd.TopLevel = false;
            this.panel1.Controls.Add(cadd);
            sadd.Hide();
            sdel.Hide();
            //pdel.Hide();
            padd.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            cadd.Show();
        }

        /*private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            pdel.TopLevel = false;
            this.panel1.Controls.Add(pdel);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            padd.Hide();
            cdel.Hide();
            rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            pdel.Show();
        }*/

        /*private void addToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            padd.TopLevel = false;
            this.panel1.Controls.Add(padd);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            pdel.Hide();
            cdel.Hide();
            rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            padd.Show();

        }*/

        private void modifyCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cdel.TopLevel = false;
            this.panel1.Controls.Add(cdel);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            padd.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            cdel.Show();
        }

        /*private void receiptDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rdet.TopLevel = false;
            this.panel1.Controls.Add(rdet);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            pdel.Hide();
            padd.Hide();
            cdel.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            rdet.Show();
        }*/

        private void courseFeeChartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cfee.TopLevel = false;
            this.panel1.Controls.Add(cfee);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            padd.Hide();
            cdel.Hide();
            //rdet.Hide();
            cmod.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            cfee.Show();
        }

        private void deleteCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmod.TopLevel = false;
            this.panel1.Controls.Add(cmod);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            padd.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            cmod.Show();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            supd.TopLevel = false;
            this.panel1.Controls.Add(supd);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            padd.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            supd.Show();
        }

        /*private void paymentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }*/

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //abt.Show();
        }

        private void Form0_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void duplicatePaymentRecieptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void makePaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            padd.TopLevel = false;
            this.panel1.Controls.Add(padd);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            dpr.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            padd.Show();
        }

        private void paymentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void aboutRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            abt.Show();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("logging out & exiting the application");
            Application.Exit();
        }

        private void duplicatePaymentRecieptToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dpr.TopLevel = false;
            this.panel1.Controls.Add(dpr);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            padd.Hide();
            pd.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            dpr.Show();
        }

        private void paymentDetailsToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            pd.TopLevel = false;
            this.panel1.Controls.Add(pd);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            padd.Hide();
            dpr.Hide();
            sr.Hide();
            csr.Hide();
            clr.Hide();
            pd.Show();
        }

        private void studentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            sr.TopLevel = false;
            this.panel1.Controls.Add(sr);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            padd.Hide();
            dpr.Hide();
            pd.Hide();
            csr.Hide();
            clr.Hide();
            sr.Show();
        }

        private void courseReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            csr.TopLevel = false;
            this.panel1.Controls.Add(csr);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            padd.Hide();
            dpr.Hide();
            pd.Hide();
            //csr.Hide();
            clr.Hide();
            sr.Hide();
            csr.Show();
        }

        private void collectionReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clr.TopLevel = false;
            this.panel1.Controls.Add(clr);
            sadd.Hide();
            sdel.Hide();
            cadd.Hide();
            //pdel.Hide();
            cdel.Hide();
            //rdet.Hide();
            cfee.Hide();
            cmod.Hide();
            supd.Hide();
            padd.Hide();
            dpr.Hide();
            pd.Hide();
            csr.Hide();
            //clr.Hide();
            sr.Hide();
            clr.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        /*private void personalInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }*/

        /*private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ad.TopLevel = false;
            this.panel1.Controls.Add(ad);
            ad.Show();
        }*/
    }
}
