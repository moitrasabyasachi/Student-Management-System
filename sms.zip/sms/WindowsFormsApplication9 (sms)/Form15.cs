﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form15 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        OleDbDataReader dr;
        //string en,nm,crs,tcf,mnth,pa,tpa,pm,chq_dd_no,bk,br,rn,rd;

        public Form15()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select reciept_no from collection where enroll_no='"+textBox1.Text+"'", con);
                
                con.Open();
                
                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr[0].ToString());
                }

                int c = listBox1.Items.Count;
                if (c==0)
                {
                    MessageBox.Show("student not found");
                    textBox1.Clear();
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {            
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();

            textBox2.Focus();
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                com = new OleDbCommand("select enroll_no,sname,cname,pay_type,part,fee,stax,paid_amt,tcf,total_paid_amt,pay_mode,chq_dd_no,bank,branch from " + textBox1.Text + " where reciept_no=@p1", con);

                con.Open();

                com.Parameters.AddWithValue("@p1", textBox2.Text);

                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    textBox3.Text = dr[0].ToString();
                    textBox4.Text = dr[1].ToString();
                    textBox5.Text = dr[2].ToString();
                    textBox6.Text = dr[3].ToString();
                    textBox7.Text = dr[4].ToString();
                    textBox8.Text = dr[5].ToString();
                    textBox9.Text = dr[6].ToString();
                    textBox10.Text = dr[7].ToString();
                    textBox11.Text = dr[8].ToString();
                    textBox12.Text = dr[9].ToString();
                    textBox13.Text = dr[10].ToString();
                    textBox14.Text = dr[11].ToString();
                    textBox15.Text = dr[12].ToString();
                    textBox16.Text = dr[13].ToString();
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string dt = DateTime.Now.ToString("dd-MM-yyyy");

            Form f6 = new Form6(textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text, textBox9.Text, textBox10.Text, textBox11.Text, textBox12.Text, textBox13.Text, textBox14.Text, textBox15.Text,textBox16.Text,textBox2.Text + " (duplicate)",dt.ToString());

            textBox1.Clear();
            listBox1.Items.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
            textBox15.Clear();
            textBox16.Clear();

            textBox1.Focus();

            f6.Show();            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            listBox1.Items.Clear();

            textBox1.Focus();
        }
    }
}
