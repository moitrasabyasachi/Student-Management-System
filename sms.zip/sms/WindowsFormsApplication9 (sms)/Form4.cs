﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form4 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com,com1;
        OleDbDataReader dr;
        int i;

        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    com = new OleDbCommand("insert into student values(@p1,@p2,@p3,@p4,@p10,@p5,@p6,@p7,@p8,@p9,p11,p12)", con);

                    com1 = new OleDbCommand("create table " + textBox1.Text + "(enroll_no Text,sname Text,cname Text,c_str_dt Text,c_end_dt Text,cfee Text,stax Text,tcf Text,pay_type Text,part Text,fee Text,paid_amt Text,total_paid_amt Text,due_amt Text,pay_mode Text,chq_dd_no Text,bank Text,branch Text,reciept_no Text,reciept_dt Text)", con);

                    con.Open();
                    com.Parameters.AddWithValue("@p1", textBox1.Text);
                    com.Parameters.AddWithValue("@p2", textBox2.Text);
                    com.Parameters.AddWithValue("@p3", richTextBox1.Text);
                    com.Parameters.AddWithValue("@p4", textBox3.Text);
                    com.Parameters.AddWithValue("@p10", textBox7.Text);
                    com.Parameters.AddWithValue("@p5", textBox4.Text);
                    com.Parameters.AddWithValue("@p6", dateTimePicker1.Text);

                    if (radioButton1.Checked == true)
                        com.Parameters.AddWithValue("@p7", radioButton1.Text);

                    else if (radioButton2.Checked == true)
                        com.Parameters.AddWithValue("@p7", radioButton2.Text);

                    com.Parameters.AddWithValue("@p8", textBox6.Text);
                    com.Parameters.AddWithValue("@p9", comboBox1.Text);
                    com.Parameters.AddWithValue("@p11", dateTimePicker2.Text);
                    com.Parameters.AddWithValue("@p12", dateTimePicker3.Text);

                    if (textBox1.Text == "" || textBox2.Text == "" || richTextBox1.Text == "" || textBox3.Text == "" || (radioButton1.Checked == false && radioButton2.Checked == false) || textBox6.Text == "" || comboBox1.Text == "--SELECT--")
                    {
                        MessageBox.Show("information incomplete, check once");
                    }
                    else
                    {
                        i = com.ExecuteNonQuery();
                        com1.ExecuteNonQuery();
                        MessageBox.Show(i + " record inserted successfully ");

                        textBox1.Clear();
                        textBox2.Clear();
                        richTextBox1.Clear();
                        textBox3.Clear();
                        textBox7.Clear();
                        textBox4.Clear();
                        dateTimePicker1.ResetText();
                        radioButton1.Checked = false;
                        radioButton2.Checked = false;
                        textBox6.Clear();
                        comboBox1.Text = "--SELECT--";
                        dateTimePicker2.ResetText();
                        dateTimePicker3.ResetText();
                    }
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            textBox1.Focus();

            try
            {
                com = new OleDbCommand("select cname from course", con);

                con.Open();

                dr = com.ExecuteReader();

                while (dr.Read())
                {
                    comboBox1.Items.Add(dr[0].ToString());
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }

        }

        /*private void label12_Click(object sender, EventArgs e)
        {

        }*/

        /*private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }*/

        /*private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }*/

        /*private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }*/
    }
}
