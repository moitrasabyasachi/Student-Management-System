﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form9 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Database\\register.accdb");
        OleDbCommand com;
        int i;

        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Really want to proceed?", "Confirm proceed", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    com = new OleDbCommand("delete from course where cid=@p1", con);
                    con.Open();
                    com.Parameters.AddWithValue("@p1", textBox1.Text);
                    i = com.ExecuteNonQuery();
                    if (i == 0)
                        MessageBox.Show("Record not found");
                    else if (i > 0)
                        MessageBox.Show(i + " record deleted successfully");
                    textBox1.Clear();
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }
    }
}
