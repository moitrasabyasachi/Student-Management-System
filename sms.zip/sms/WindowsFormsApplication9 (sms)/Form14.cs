﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication9__sms_
{
    public partial class Form14 : Form
    {
        Timer tmr;
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Shown(object sender, EventArgs e)
        {
            tmr = new Timer();
            tmr.Interval = 3000;
            tmr.Start();
            tmr.Tick += tmr_Tick;
        }
        void tmr_Tick(object sender, EventArgs e)
        {
            tmr.Stop();
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
